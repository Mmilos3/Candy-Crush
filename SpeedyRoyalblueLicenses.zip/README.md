# HTML, CSS, and JavaScript

This is the Template Repl for HTML, CSS, and JavaScript.

HTML, CSS, and JavaScript are the languages that make up the web. Every web page you see in your browser uses each of these to some degree.

Check out Mozilla's docs for each here:
- [HTML](https://developer.mozilla.org/en-US/docs/Web/HTML)
- [CSS](https://developer.mozilla.org/en-US/docs/Web/CSS)
- [JavaScript](https://developer.mozilla.org/en-US/docs/Web/JavaScript)